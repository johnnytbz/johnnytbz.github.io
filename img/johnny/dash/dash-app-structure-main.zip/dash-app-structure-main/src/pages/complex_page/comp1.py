#notes
'''
If a page has a lot of components, I suggest splitting them up into their own files such as this one.
'''

# package imports
from dash import html

random_component = html.Div('This is a random component specific to the current page.')
