﻿﻿# 15:17 2020/8/13
# Fargo Client

# 实验目的：
1. 使用Fargo客户端，部署在局域网主机上，能使用Fargo服务端主动发起通讯，实时浏览主机文件目录并下载文件。
2. 重点1：实时获取，不需要修改任何网络配置。
3. 重点1：外网向内网主动发起请求，不需要修改任何网络配置。

# 实验步骤：

1. 确保有Java运行时环境JRE。若没有则下载解压安装，链接如下。
    http://www.aka10.com/store/fargo/deploy/jre1.8.0_221.zip
   在fclient.bat文件中设置好路径，如set jre=C:\jre8

2. 确保有Fargo客户端。若没有则解压安装，链接如下。
    http://www.aka10.com/store/fargo/deploy/fargo-latest.7z

3. 修改配置文件config-zoo.txt，设置要共享的文件夹，可任意多个
   此设置fargo.stores=all表示共享所有的磁盘目录。

4. 双击fclient-ok.bat，弹出黑色窗口，若一切正常则窗口会显示目录信息和http地址如：
   They can be founnd at http://www.aka10.com/fargo/CN-00122160-Shelly08

5. 复制http地址，打开浏览器并打开网页。
   在网页显示窗口的右上角，有当前页面的二维码，可手机扫码进入，浏览文件和下载。
   重点，二维码，方便，实用。
   重点，手机和你局域网的电脑通讯，毫无障碍
   重点，无侵入。

6. 点击相关目录，进行目录浏览；点击相关文件，进行下载。

7. 步骤相关截图在这里：
   http://www.aka10.com/store/fargo/deploy/steps?view

# 免责声明：
1. 本人不会恶意浏览，下载任何内容。
2. Fargo服务端，可由主机的负责人控制。
3. 仅出于实验目的，探索发明的艰难
4. 作者联系方式，在网页底部有邮箱和微信