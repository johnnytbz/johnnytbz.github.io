from dash import html
import feffery_utils_components as fuc
import feffery_antd_components as fac


def render(button_perms):

    return html.Div('我是数据监控')
