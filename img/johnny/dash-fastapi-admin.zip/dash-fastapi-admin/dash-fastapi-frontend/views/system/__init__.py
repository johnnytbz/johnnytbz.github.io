from . import (
    user,
    role,
    menu,
    dept,
    post,
    dict,
    config,
    notice
)
