from .table1 import table1
from .table2 import table2