from .sales_chart import salesChart
from .cards import customers, revenue, bounceRate
from .page_visits_table import pageVisitsTable
from .team_members import teamMembers
from .progress_track import progressTrack
from .total_orders import totalOrdersBarChart
from .global_rank import rankingPanel
from .acquisition import acquisition
from .button_bar_buttons import newTasksButton