from dash_bootstrap_components import __version__


def test_version():
    assert __version__ == "1.5.1-dev"
