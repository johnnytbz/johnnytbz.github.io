BOOTSTRAP = (
    "https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/"
    "font/bootstrap-icons.css"
)
FONT_AWESOME = "https://use.fontawesome.com/releases/v6.3.0/css/all.css"
