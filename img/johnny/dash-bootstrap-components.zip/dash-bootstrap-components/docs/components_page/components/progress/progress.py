import dash_bootstrap_components as dbc

progress = dbc.Progress(value=50)
