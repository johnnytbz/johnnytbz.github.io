import dash_bootstrap_components as dbc

button_group = dbc.ButtonGroup(
    [dbc.Button("Left"), dbc.Button("Middle"), dbc.Button("Right")]
)
